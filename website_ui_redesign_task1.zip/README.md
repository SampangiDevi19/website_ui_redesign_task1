# Website UI Redesign (Task 1)

Objective:
Redesign a simple website interface to improve:
- Clarity
- Structure
- Visual appeal
- Navigation

Issues Identified:
1. Poor layout
2. Weak color usage
3. Confusing navigation

Improvements:
- Responsive header
- Consistent blue/white color palette
- Card-based content sections
- Better spacing and typography
- Clear call-to-action button

Files:
- index.html
- style.css
- README.md
